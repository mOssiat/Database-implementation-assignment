package com.example.androidsql;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private BookDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        dbHelper = new BookDatabaseHelper(this);
    }

    // Method to handle Login button click
    public void onLoginButtonClicked(View view) {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate login credentials
        if (validateLogin(username, password)) {
            // Navigate to main activity or any other activity on successful login
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish(); // close login activity so user cannot come back to it after logging in
        } else {
            // Show error message or handle unsuccessful login
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to handle Register button click
    public void onRegisterButtonClicked(View view) {
        // Navigate to RegisterActivity
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

    // Method to validate login credentials
    private boolean validateLogin(String username, String password) {
        Cursor cursor = dbHelper.readUser(username, password);
        if (cursor != null && cursor.moveToFirst()) {
            return true;
        }
        return false;
    }
}
